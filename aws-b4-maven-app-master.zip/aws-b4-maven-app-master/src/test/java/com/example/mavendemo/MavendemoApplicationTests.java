package com.example.mavendemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavendemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
